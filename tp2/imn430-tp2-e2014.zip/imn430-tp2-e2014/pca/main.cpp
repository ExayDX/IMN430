//
//  main.cpp
//  IMN430 TP2 - PCA
//

#include "Cimg.h"
#include "PCA.h"

#include <iostream>
#include <math.h>

int main (int argc, char** argv)
{ 
	// Load images

	// Get eigenValues and eigenVectors from PCA
    
	// Align images
    
    return 0;
}